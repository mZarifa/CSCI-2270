#include <iostream>
#include <fstream>
#include <math.h>
#include <iomanip>
#include <string>
#include <vector>
#include <stdio.h>
#include <chrono>
#include <unistd.h>
#include <thread>

#include "arrayHelper.hpp"

using namespace std;

struct HashNode //create structure
{
  int key;

  HashNode()
  {
    key = 0;
  }
  HashNode(int k)
  {
    key = k;
  }
  ~HashNode() {}
};

class HashTable //create class with table size.
{
  HashNode **table;
  int size;

public:
  HashTable() //create a table with size 40009 by deafult.
  {
    size = 40009;
    table = new HashNode *[40009];
    for (int i = 0; i < size; i++)
      table[i] = 0;
  }

  HashTable(int s) //custom size if youre cool or something
  {
    size = s;
    table = new HashNode *[s];
    for (int i = 0; i < size; i++)
      table[i] = 0;
  }

  ~HashTable() { delete[] table; }

  void insert(int key) //insert function
  {
    HashNode *node = new HashNode(key); //make a new node with data of key.
    int index = hashCode(key, size);    //run it through the hash function

    if (table[index] == 0) //if the index is 0, thats the starter node
      table[index] = node;
    else if (table[index]->key == key) //this outputted a lot of trash
    {
      // cerr << "Key in use with :" << table[index] << " \n";
    }
    else
    {
      for (int i = (index + 1) % size; i != index; i = (i + 1) % size) //else add 1 to the index and try and move forward again.
      {
        if (table[i] == 0)
        {
          table[i] = node;
          return;
        }
        else if (table[i]->key == key)
        {
          // cerr << "Key already in use with :" << table[index] << " \n";
          return;
        }
      }
      // cerr << "Can not insert (" << key << ", " << ")Table is full" << endl;
      return;
    }
  }
  HashNode *search(int key) //search function
  {
    int index = hashCode(key, size); //run the hash function
    if (table[index] == 0)
      return 0;
    else if (table[index]->key == key)
      return table[index];
    else
    {
      for (int i = (index + 1) % size; i != index; i = (i + 1) % size) //same as before, iterate through the table
      {
        if (table[i] == 0)
          return 0;
        else if (table[i]->key == key)
          return table[i];
      }
      return 0;
    }
  }

  int hashCode(int k, int table_size) //the literal hash function
  {
    int hash = 0;

    hash = hash + k;
    return hash % table_size;
  }
};

arrayHelper dataSetA;
arrayHelper dataSetB;
HashTable bigtable(40009);
float insert[400];
float search[400];

int main()
{
  using namespace std::chrono;

  dataSetA.openAndRead("dataSetA.csv"); //read the data
  dataSetB.openAndRead("dataSetB.csv");

  int count = 0;
  float per100avg = 0;
  for (int i = 0; i < 40009; i++)
  {
    auto start = high_resolution_clock::now();
    bigtable.insert(dataSetA.getTestArray(i));
    auto end = high_resolution_clock::now();
    per100avg += duration_cast<nanoseconds>(end - start).count();
    // cout << duration_cast<nanoseconds>(end - start).count() << endl;
    if (i % 100 == 0)
    {
      insert[count] = per100avg / 100;
      count++;
      per100avg = 0;
    }
  }

  count = 0;
  per100avg = 0;
  for (int i = 0; i < 40009; i++)
  {
    auto start = high_resolution_clock::now();
    bigtable.search(dataSetA.getTestArray(i));
    auto end = high_resolution_clock::now();
    per100avg += duration_cast<nanoseconds>(end - start).count();
    // cout << duration_cast<nanoseconds>(end - start).count() << endl;
    if (i % 100 == 0)
    {
      search[count] = per100avg / 100;
      count++;
      per100avg = 0;
    }
  }
  string fileName = "LinearHash.csv"; //create the linearHash.csv file for easy export
  ofstream out_File;
  out_File.open(fileName);
  out_File.clear();

  for (int j = 0; j < 400; j++)
  {
    out_File << insert[j] << ",";
  }
  out_File << endl;
  for (int j = 0; j < 400; j++)
  {
    out_File << search[j] << ",";
  }
  out_File << endl;

  //------------------------------------------------------------------------------------------------------
  //-------------------------------------B Data---------------------------------------------------------
  //------------------------------------------------------------------------------------------------------------

  count = 0;
  per100avg = 0;
  for (int i = 0; i < 40009; i++)
  {
    auto start = high_resolution_clock::now();
    bigtable.insert(dataSetA.getTestArray(i));
    auto end = high_resolution_clock::now();
    per100avg += duration_cast<nanoseconds>(end - start).count();
    // cout << duration_cast<nanoseconds>(end - start).count() << endl;
    if (i % 100 == 0)
    {
      insert[count] = per100avg / 100;
      count++;
      per100avg = 0;
    }
  }

  count = 0;
  per100avg = 0;
  for (int i = 0; i < 40009; i++)
  {
    auto start = high_resolution_clock::now();
    bigtable.search(dataSetA.getTestArray(i));
    auto end = high_resolution_clock::now();
    per100avg += duration_cast<nanoseconds>(end - start).count();
    // cout << duration_cast<nanoseconds>(end - start).count() << endl;
    if (i % 100 == 0)
    {
      search[count] = per100avg / 100;
      count++;
      per100avg = 0;
    }
  }

  for (int j = 0; j < 400; j++)
  {
    out_File << insert[j] << ",";
  }
  out_File << endl;
  for (int j = 0; j < 400; j++)
  {
    out_File << search[j] << ",";
  }
  out_File << endl;

  out_File.close();
}
